# Review-Generator

Generates targeted product reviews in Python using TensorFlow's Keras
to create an unsupervised deep learning model. 

Our model trains using real world categorized product reviews.
