# Video-Emmbeddings
Unsupervised Learning on videos using TensorFlow 2.0, Keras
OpenCV is used only for initial preprocessing. 

Converting a video (.mp4 format) in to say 256 column vector. So that it can be used for ad reccomendations. 

Please see the file Main.ipynb file. 

Data used : Fun2.mp4

Coming Soon : Using LSTMs only


Refereces : 1. https://arxiv.org/pdf/1502.04681.pdf
            
            2. https://www.kaggle.com/valkling/how-to-teach-an-ai-to-dance
